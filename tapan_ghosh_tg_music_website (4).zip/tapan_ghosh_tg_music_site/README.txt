TAPAN GHOSH | TG MUSIC — WEBSITE FILES

Included:
- index.html: one-page artist profile website
- assets/tapan-ghosh-artist-photo.jpg: the photo supplied for this page (if available)

How to use:
1. Open index.html to preview the website in a browser.
2. To publish online, upload these files to a static hosting service or recreate the page in Google Sites.
3. For Google Sites, the HTML file cannot usually be imported as a whole website. Use it as a design/content reference: copy the text, upload the photo, and add the YouTube link.
4. Google indexing and search visibility are not guaranteed.

Important:
- Check that all credits accurately reflect the real contributions before publishing.
- This website package has not been published to your Google account or to the internet.
